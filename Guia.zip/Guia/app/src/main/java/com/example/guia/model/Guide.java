package com.example.guia.model;

public class Guide {
    int imgGuide;
    String guideName;
    String guideDescription;

    public Guide(int imgGuide, String guideName, String guideDescription) {
        this.imgGuide = imgGuide;
        this.guideName = guideName;
        this.guideDescription = guideDescription;
    }

    public int getImgGuide() {
        return imgGuide;
    }

    public String getGuideName() {
        return guideName;
    }

    public String getGuideDescription() {
        return guideDescription;
    }

}
