package com.example.guia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.guia.adapter.GuideAdapter;
import com.example.guia.databinding.ActivityMainBinding;
import com.example.guia.model.Guide;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private GuideAdapter guideAdapter;
    private ArrayList<Guide> guideList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        RecyclerView recyclerViewGuide = binding.RecyclerViewGuide;
        recyclerViewGuide.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewGuide.setHasFixedSize(true);
        guideAdapter = new GuideAdapter(guideList, this);
        recyclerViewGuide.setAdapter(guideAdapter);
        getGuide();

    }

    private void  getGuide(){

        Guide guide1 = new Guide(
            R.drawable.zoo,
                "Zoológico",
                "O Zoológico de Sorocaba é um destino encantador para amantes da natureza e animais."
        );
        guideList.add(guide1);

        Guide guide2 = new Guide(
                R.drawable.pda,
                "Parque das Águas",
                "O Parque das Águas é um local encantador que oferece uma atmosfera tranquila e natural para os visitantes."
        );
        guideList.add(guide2);

        Guide guide3 = new Guide(
                R.drawable.iguatemi,
                "Iguatemi Esplanada",
                "O Shopping Iguatemi é um dos principais centros de compras e entretenimento em Sorocaba."
        );
        guideList.add(guide3);
    }
}