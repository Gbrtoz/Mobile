package com.example.guia.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.guia.databinding.GuideItemBinding;
import com.example.guia.model.Guide;

import java.util.ArrayList;

public class GuideAdapter extends RecyclerView.Adapter<GuideAdapter.GuideViewHolder> {

    private final ArrayList<Guide> guideList;
    private final Context context;

    public GuideAdapter(ArrayList<Guide> guideList, Context context) {
        this.guideList = guideList;
        this.context = context;
    }

    @NonNull
    @Override
    public GuideViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        GuideItemBinding listItem;
        listItem = GuideItemBinding.inflate(LayoutInflater.from(context), parent, false);
        return new GuideViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(@NonNull GuideViewHolder holder, int position) {

        holder.binding.imgGuide.setBackgroundResource(guideList.get(position).getImgGuide());
        holder.binding.txtGuideName.setText(guideList.get(position).getGuideName());
        holder.binding.txtGuideDescription.setText(guideList.get(position).getGuideDescription());
    }

    @Override
    public int getItemCount() {
        return guideList.size();
    }

    public static class GuideViewHolder extends RecyclerView.ViewHolder{

        GuideItemBinding binding;

        public GuideViewHolder(GuideItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

}
